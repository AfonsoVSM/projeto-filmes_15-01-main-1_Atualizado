<?php

if($_SERVER['REQUEST_METHOD']=="GET"){
if(isset($_GET['autor'])&& is_numeric($_GET['autor'])){
$idAutor=$_GET['autor'];
$con = new msqli ("localhost","root","","autores");

if($con->connect_errno!=0){
echo "<h1>Ocorreu um erro no acesso à base de dados. <br>".$con->connect_error."</h1>";
exit();
}
$sql="Select * from autors where id_autor=?";
$stm= $execute();
$res=$stm->get_result();
$livro=$res->fetch_assoc();
$stm->close();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO_8859-1">
<title>Editar Autor</title>
</head>
<body>
<h1>Editar Autores</h1>
<form action="autores_update.php"method="post">
<label>Nome</label><input type="text" name="nome" required value="<?php echo $livro['nome'];?>"><br>
<label>Nacionalidade</label><input type="text" name="nacionalidade" required value="<?php echo $livro['nacionalidade'];?>"><br>
<label>Data de nascimento</label><input type="text" name="data_de_nascimento" required value="<?php echo $livro['data_de_nascimento'];?>"><br>

<input type="submit" name="enviar"><br>
</form>
</body>
<?php
}
else{
echo ('<h1>Houve um erro ao processar o seu pedido.<br>Dentro de segundos será reencaminhado!</h1>');
header("refresh:5,url=index.php");
}


