<?php
if($_SERVER['REQUEST_METHOD']=="POST"){

	$nome="";
	$nacionalidade="";
	$data_de_nascimento="";
	

	if (isset($_POST['nome'])) {

		$nome=$_POST['nome'];
	}
	else{
		echo'<script>alert("É obrigatório o preenchimento do nome.");</script>';
	}
	if (isset ($_POST['nacionalidade'])) {
		$nacionalidade=$_POST['nacionalidade'];
	}
	if (isset ($_POST['data_de_nascimento'])&& is_numeric($_POST['data_de_nascimento'])) {
		$data_de_nascimento=$_POST['data_de_nascimento'];
	}
	

	$con=new mysqli("localhost","root","","filmes");
	if($con->connect_errno!=0){
		echo "Ocorreu um erro no acesso á base de dados.<br>".$con->connect_error;
		exit;
	}
	else{

		$sql='insert into autores (nome,nacionalidade,data_de_nascimento) values (?,?,?)';
		$stm = $con->prepare( $sql);
		if ($stm!=false){
			$stm->bind_param('sssis',$nome,$nacionalidade,$data_de_nascimento);
			$stm->execute();
			$stm->close();

			echo '<script>alert("Autor adicionado com sucesso");</script>';
			echo 'Aguarde um momento.A reencaminhar página';
			header("refresh:5; url=index.php");

		}
		else{
			echo ($con->error);
			echo 'Aguarde um momento.A reencaminhar página';
			header("refresh:5; url=index.php");
		}
	}




}
else {
	?>

	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="ISO=8859-1">
		<title>Adicionar Autores</title>
	</head>
	<body>
		<h1>Adicionar Autores</h1>
		<form action="autores_create.php" method="post">
			<label>nome</label><input type="text" name="nome" required><br>
			<label>nacionalidade</label><input type="text" name="nacionalidade" ><br>
			<label>data_de_nascimento</label><input type="date" name="data_de_nascimento" ><br>
			<input type="submit" name="enviar">
		
		</form>
		
	</body>
	</html>
	<?php
} 
?>

