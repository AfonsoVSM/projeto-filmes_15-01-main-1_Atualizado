<?php
session_start();
$con=new mysqli("localhost","root", "","filmes");

if($con->connect_errno!=0){
	echo "Ocorreu um erro no acesso á base de dados".$con->connect_error;
	exit;
}
else {
	if (!isset($_SESSION['login'])){
		$_SESSION['login']="incorreto";
	}
		if ($_SESSION['login']="correto"){


	?>
	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="ISO-8859-1">
	<title>filmes</title>
	</head>
	<body>
		<a href="filmes_create.php">Create</a>
		<h1>Lista de Filmes</h1>
		<?php
		$stm=$con->prepare('select * from filmes');
		$stm->execute();
		$res=$stm->get_result();
		while($resultado = $res->fetch_assoc()){
			echo '<a href="filmes_show.php?filme='.$resultado['id_filme'].'">';
			
			echo $resultado["titulo"];
			echo "</a> ";
			echo '<a href="filmes_edit.php?filme='.$resultado['id_filme'].'"> edit</a>';
			echo '<a href="filmes_delete.php?filme='.$resultado['id_filme'].'"> delete</a>';
			echo "<br>";
		}
		$stm->close();
		?>
	<br>
	</body>
	</html>
<br>
	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="ISO-8859-1">
	<title>filmes</title>
	</head>
	<body>
		<a href="atores_create.php">Create</a>
		<h1>Lista de Atores</h1>
		<?php
		$stm=$con->prepare('select * from atores');
		$stm->execute();
		$res=$stm->get_result();
		while($resultado = $res->fetch_assoc()){
			echo '<a href="atores_show.php?ator='.$resultado['id_ator'].'">';
			
			echo $resultado["nome"];
			echo "</a> ";
			echo '<a href="atores_edit.php?filme='.$resultado['id_ator'].'"> edit</a>';
			echo '<a href="atores_delete.php?filme='.$resultado['id_ator'].'"> delete</a>';
			echo "<br>";
		}
		$stm->close();
		?>
	<br>
	</body>
	</html>
<br>
	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="ISO-8859-1">
	<title>filmes</title>
	</head>
	<body>
		<a href="utilizadores_create.php">Create</a>
		<h1>Lista de Utilizadores</h1>
		<?php
		$stm=$con->prepare('select * from utilizadores');
		$stm->execute();
		$res=$stm->get_result();
		while($resultado = $res->fetch_assoc()){
			echo '<a href="utilizadores_show.php?utilizadores='.$resultado['id_utilizadores'].'">';
			
			echo $resultado["nome"];
			echo "</a> ";
			echo '<a href="utilizadores_edit.php?utilizadorese='.$resultado['id_utilizadores'].'"> edit</a>';
			echo '<a href="utilizadores_delete.php?utilizadores='.$resultado['id_utilizadores'].'"> delete</a>';
			echo "<br>";
		}
		$stm->close();
		?>
	<br>
	</body>
	</html>
<br>

<?php
}//se login==correto
else {
	echo 'Para entrar nesta pagina necessita de efetuar <a href="login.php">login</a>';
	header('refresh: 2; url=login.php');
}

}//end if - if($con->connect_errno!=0)
?>

